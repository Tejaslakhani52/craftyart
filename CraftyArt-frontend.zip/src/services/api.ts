import axios, {AxiosInstance} from "axios"
import {AllDataRoot} from "../interfaces/AllDataObject"
import {CatDataRoot} from "../interfaces/CatDataObject";

class ApiService {
    base: AxiosInstance

    constructor() {
        this.base = axios.create({
            baseURL: "https://craftyverse.in/templates/api/",
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
            },
            withCredentials: false
        })
    }

    getDatas = (props: { key: string, page: number, count: number }): Promise<AllDataRoot> => {
        return new Promise((resolve, reject) => {
            this.base
                .post("getDatas", props)
                .then(({data}) => {
                    resolve(data)
                })
                .catch((err) => reject(err))
        })
    }

    getCategoryDatas = (props: { debug_key: string, cat_id: number, page: number }): Promise<CatDataRoot> => {
        return new Promise((resolve, reject) => {
            this.base
                .post("getCategoryDatas", props)
                .then(({data}) => {
                    resolve(data)
                })
                .catch((err) => reject(err))
        })
    }
}

export default new ApiService()
